package com.example.service;



import com.example.entity.Inquiry;

public interface InquiryService {
	Inquiry createInquiry(Inquiry inquiry);
	
}

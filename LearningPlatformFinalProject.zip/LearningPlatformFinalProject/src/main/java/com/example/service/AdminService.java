package com.example.service;
import com.example.entity.Admin;
public interface AdminService {
	
	public Admin registerAdmin(Admin admin);
	public Admin loginAdmin(String email, String password);
	

	

   
   }
	
		
	


